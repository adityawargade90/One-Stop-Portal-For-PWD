import express from "express";

const router = express.Router();

/**
 * POST /ai-assistant
 *
 * Accepts { messages, type, userProfile } and streams an SSE response from
 * the Google Gemini 1.5 Flash API, re-emitted in OpenAI SSE format so the
 * frontend parser requires no changes.
 *
 * Supported `type` values:
 *   "skill-gap"             – returns JSON skill-gap analysis
 *   "smart-recommendations" – returns JSON personalised recommendations
 *   "job-match"             – returns JSON job match scores
 *   "scheme-check"          – returns JSON scheme eligibility
 *   "resume"                – returns JSON resume / profile feedback
 *   (anything else)         – general conversational assistant
 */
router.post("/", async (req, res) => {
  const { messages, type, userProfile } = req.body;

  const GEMINI_API_KEY = process.env.GEMINI_API_KEY;
  if (!GEMINI_API_KEY) {
    return res.status(500).json({ error: "GEMINI_API_KEY is not configured" });
  }

  // Build system prompt based on request type
  let systemPrompt = `You are the Smart Portal AI Assistant — a helpful, empathetic, and knowledgeable guide for persons with disabilities (PWD) in India.

Your role:
- Help users find suitable jobs, government schemes, courses, and services
- Provide career guidance and skill improvement suggestions
- Analyse resumes and provide feedback
- Check scheme eligibility based on user data
- Be sensitive, encouraging, and accessibility-aware

User Profile Context:
${userProfile ? JSON.stringify(userProfile, null, 2) : "No profile data available"}

Guidelines:
- Always be respectful about disability
- Provide actionable, specific recommendations
- Mention scheme names, eligibility criteria, and deadlines when relevant
- Suggest skill improvements based on job market trends
- Keep responses concise but thorough
- Support both Hindi and English queries`;

  if (type === "skill-gap") {
    systemPrompt = `You are an AI Skill Gap Analyser. Given a user's current skills and their target job role, analyse the gap.
Return ONLY valid JSON (no markdown, no code fences) in this exact format:
{
  "skills": [
    {"name": "Skill Name", "current": 0-100, "target": 80-100, "gap": "description of gap and what to learn", "status": "gap|on-track|complete"}
  ],
  "insight": "One paragraph of actionable career advice",
  "overallReadiness": 0-100
}
Analyse 4-6 relevant skills. Be specific about what to learn. User Profile: ${userProfile ? JSON.stringify(userProfile) : "No profile"}`;
  } else if (type === "smart-recommendations") {
    systemPrompt = `You are an AI recommendation engine for persons with disabilities in India. Based on the user's profile (skills, disability type, education, location), suggest personalised opportunities.
Return ONLY valid JSON (no markdown, no code fences) in this exact format:
{
  "recommendations": [
    {"type": "job|scheme|course", "title": "Title", "subtitle": "Provider or details", "match": 0-100, "reason": "Why this matches", "tags": ["tag1"], "action": "Apply Now|Check Eligibility|Start Learning"}
  ]
}
Return exactly 3 recommendations: 1 job, 1 scheme, 1 course. User Profile: ${userProfile ? JSON.stringify(userProfile) : "No profile"}`;
  } else if (type === "job-match") {
    systemPrompt = `You are an AI Job Match Scorer. Given a user's profile and a list of jobs, score each job for compatibility.
Return ONLY valid JSON (no markdown, no code fences) in this exact format:
{
  "matches": [
    {"jobId": "id", "score": 0-100, "reasons": ["reason1", "reason2"], "missingSkills": ["skill1"]}
  ]
}
Be accurate based on skill overlap, accessibility needs, and location. User Profile: ${userProfile ? JSON.stringify(userProfile) : "No profile"}`;
  } else if (type === "scheme-check") {
    systemPrompt = `You are an AI Government Scheme Eligibility Advisor for persons with disabilities in India.
Return ONLY valid JSON (no markdown, no code fences) in this exact format:
{
  "schemes": [
    {"name": "Scheme Name", "ministry": "Ministry Name", "eligible": true, "confidence": 0-100, "reason": "Why eligible or not", "action": "What to do next"}
  ],
  "summary": "Overall assessment and top recommendation",
  "totalEligible": 0
}
Analyse all government schemes relevant to PWD. User Profile: ${userProfile ? JSON.stringify(userProfile) : "No profile"}`;
  } else if (type === "resume") {
    systemPrompt = `You are an expert AI Resume & Career Advisor specialising in helping persons with disabilities (PWD) in India find employment.
Analyse the user's profile and provide detailed, actionable feedback.
Return ONLY valid JSON (no markdown, no code fences) in this exact format:
{
  "score": 0-100,
  "strengths": ["strength1", "strength2"],
  "improvements": [{"area": "Area Name", "issue": "What's missing", "suggestion": "How to fix it"}],
  "profileSummary": "A professional bio paragraph they can use",
  "keyRecommendations": ["rec1", "rec2", "rec3"],
  "pwdTips": ["tip1", "tip2"]
}
Be encouraging, specific, and disability-inclusive in your feedback. User Profile: ${userProfile ? JSON.stringify(userProfile) : "No profile"}`;
  }

  try {
    // Convert messages from OpenAI format to Gemini format.
    // Gemini uses role "user" / "model" and a parts array.
    // System-role messages are handled via systemInstruction.
    const geminiContents = messages
      .filter((m) => m.role !== "system")
      .map((m) => ({
        role: m.role === "assistant" ? "model" : "user",
        parts: [{ text: m.content }],
      }));

    const requestBody = {
      contents: geminiContents,
      systemInstruction: { parts: [{ text: systemPrompt }] },
      generationConfig: { temperature: 0.7, maxOutputTokens: 2048 },
    };

    const aiResponse = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:streamGenerateContent?alt=sse&key=${GEMINI_API_KEY}`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(requestBody),
      }
    );

    if (!aiResponse.ok) {
      if (aiResponse.status === 429) {
        return res
          .status(429)
          .json({ error: "Rate limit exceeded. Please try again in a moment." });
      }
      if (aiResponse.status === 400 || aiResponse.status === 403) {
        return res
          .status(aiResponse.status)
          .json({ error: "Invalid or unauthorised Gemini API key. Please check your GEMINI_API_KEY." });
      }
      const errText = await aiResponse.text();
      console.error("Gemini API error:", aiResponse.status, errText);
      return res.status(500).json({ error: "AI service error" });
    }

    // Stream the response back to the client in OpenAI SSE format so the
    // existing frontend parser works without changes.
    res.setHeader("Content-Type", "text/event-stream");
    res.setHeader("Cache-Control", "no-cache");
    res.setHeader("Connection", "keep-alive");

    const reader = aiResponse.body.getReader();
    const decoder = new TextDecoder();
    let buffer = "";

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;

      buffer += decoder.decode(value, { stream: true });

      // Process complete SSE lines from the buffer
      let newlineIdx;
      while ((newlineIdx = buffer.indexOf("\n")) !== -1) {
        let line = buffer.slice(0, newlineIdx);
        buffer = buffer.slice(newlineIdx + 1);
        if (line.endsWith("\r")) line = line.slice(0, -1);
        if (!line.startsWith("data: ")) continue;

        const jsonStr = line.slice(6).trim();
        if (!jsonStr || jsonStr === "[DONE]") continue;

        try {
          const geminiChunk = JSON.parse(jsonStr);
          const text =
            geminiChunk?.candidates?.[0]?.content?.parts?.[0]?.text;
          if (text) {
            // Re-emit in OpenAI delta format
            const openAiChunk = JSON.stringify({
              choices: [{ delta: { content: text }, index: 0 }],
            });
            res.write(`data: ${openAiChunk}\n\n`);
          }
        } catch {
          // skip malformed chunk
        }
      }
    }

    res.write("data: [DONE]\n\n");
    res.end();
  } catch (err) {
    console.error("Error in /ai-assistant:", err);
    res
      .status(500)
      .json({ error: err instanceof Error ? err.message : "Unknown error" });
  }
});

export default router;
